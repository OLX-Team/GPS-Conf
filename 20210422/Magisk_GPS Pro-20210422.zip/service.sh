#!/system/bin/sh
# 开机10秒后加载
sleep 10
# 启动预定参数
./system/xbin/GPS_Pro
#