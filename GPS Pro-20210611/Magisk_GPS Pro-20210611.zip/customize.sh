# Check Enable
SKIPMOUNT=true

# system.prop
PROPFILE=false

# post-fs-data script
POSTFSDATA=false

# service script
LATESTARTSERVICE=true

# 获取系统信息
var_sdk="`grep_prop ro.*version.sdk`"
var_name="`grep_prop ro.*version.name`"
var_brand="`grep_prop ro.product.*brand`"
var_model="`grep_prop ro.product.*model`"
var_device="`grep_prop ro.product.*device`"
var_release="`grep_prop ro.*version.release`"
var_version="`grep_prop ro.*version.incremental`"
var_manufacturer="`grep_prop ro.product.*manufacturer`"
ui_print "***************"
ui_print "设备型号：$var_model"
ui_print "系统版本：$var_version"
ui_print "设备版本：$var_release"
ui_print "***************"
ui_print "邮箱: OLX_Team@88.com"

# 释放文件，普通shell命令
on_install() {
  ui_print "- 正在释放文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
  set_perm_recursive  $MODPATH/system/xbin/GPS_Pro  0  2000  0777
}
